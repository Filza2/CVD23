# CVD23 
<h1 align="center">
  <br>
  <a href="https://github.com/Filza2/CVD23"><img src="https://l.top4top.io/p_2363o1fh11.png" alt="Darkside"></a>
</h1>
<h4 align="center">we all love sabotage don't worry</h4>
<p align="center">
  <a href="http://python.org">
    <img src="https://img.shields.io/badge/python-v3-green?logoColor=blue&logo=python">
  </a>
  <a href="https://www.kali.org/">
    <img src="https://img.shields.io/badge/platform-Linux-green?logoColor=blue&logo=Linux">
  </a>
  <a href="https://www.microsoft.com/en-us/windows/">
    <img src="https://img.shields.io/badge/platform-Windows 10-blue?logoColor=blue&logo=Windows">
  </a>
  <a href="https://github.com/Filza2/CVD23">
    <img src="https://img.shields.io/badge/version-Beta-lightgrey?&logo=windowsterminal">
  </a>
  <br></br>
  <a href="https://t.me/TweakPY">
    <img src="https://img.shields.io/badge/Telegram-Filza-blue?style=plastic&logo=Telegram">
  </a>
   <a href="https://t.me/vv1ck">
    <img src="https://img.shields.io/badge/Telegram-Joker-blue?style=plastic&logo=Telegram">
  </a>
</p>

![demo](https://c.top4top.io/p_23630b4j21.jpg)

### Features:
- Terminal Controlor
- File Stealer 
- Spread
- WebBrowse
- Target informations
- Message Sender
- File Manger
- File uploder [Linux to Linux , windows to Linux , {Linux to windows not supported yet !!} ]
- Target CIPM 
- Account Stealer
- Screenshot

--> All details in README File

![save demo](https://h.top4top.io/p_2363m4qhr1.jpg)


### Operating Systems Tested

- Kali Linux 2022
- Windows 10

### Installation On Kali Linux


```bash
$ git clone https://github.com/Filza2/CVD23
$ cd CVD23
$ sudo bash Linux-installer.sh
$ python3 -m pip install -r requirments.txt
$ sudo python3 CVD-23.py
```

### Installation On Windows

```bash
$ Just download it and run installer.py File 
```

### CVD23 is Beta and for educational purposes only ..

```python
print('Thank you for downloading our Tool')
```

